import 'amfe-flexible';
import '../../base/src/main';
